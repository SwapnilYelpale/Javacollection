package com.jlt.dao;
import com.jlt.pojo.Employee;
import java.util.List;
import java.util.ArrayList;


public class EmployeeDao 
{
private List<Employee> employeeList=new ArrayList<Employee>();

public boolean addEmployee(Employee employee)
{
	System.out.println("In EmployeeDao::addEmployee");
	System.out.println(employee);
	return false;
	
	
	
	public boolean updateEmployeeSalary(int employeeid,String name,double salary)
	{
		for(Employee employee :`employeeList)
		{
			if(employee.getEmployee()=employeeid)
			{
				employeeList.update(employee);
				return true;
			}
		}
		
		
		return false;
	}
	}
}
