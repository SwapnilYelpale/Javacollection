package com.jlt.pojo;

public class Employee
{
	private int employeeid;
	private String name;
	private double salary;

public Employee() 
{
	
}
public Employee(int employeid, String name, double salary) {
	super();
	this.employeeid = employeid;
	this.name = name;
	this.salary = salary;
	
	
}


private void Employee() {
	
}

public int getEmployeid() {
	return employeeid;
}

public void setEmployeid(int employeid) {
	this.employeeid = employeid;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public double getSalary() {
	return salary;
}

public void setSalary(double salary) {
	this.salary = salary;
}
}
