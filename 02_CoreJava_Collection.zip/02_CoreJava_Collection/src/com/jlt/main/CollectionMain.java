package com.jlt.main;
import java.util.ArrayList;
import java.util.List;
import java.util.HashSet;
import java.util.Set;

import com.jlt.demo.ArrayListDemo;
import com.jlt.demo.HashMapDemo;
import com.jlt.demo.HashSetDemo;
import com.jlt.demo.TreeMapDemo;
import com.jlt.demo.TreeSetDemo;


public class CollectionMain
{
public static void main(String[] args) 
{
//ArrayListDemo ald=new ArrayListDemo();
//ald.print();
	
	//HashSetDemo hsd = new HashSetDemo();
	//hsd.printSet();
	
	//TreeSetDemo tsd=new TreeSetDemo();
	//tsd.display();
	//HashMapDemo hsd=new HashMapDemo();
	//hsd.printMap();
	
	TreeMapDemo tmd =new TreeMapDemo();
	tmd.print();
}
}
