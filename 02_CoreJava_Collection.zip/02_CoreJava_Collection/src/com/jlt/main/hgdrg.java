package com.jlt.main;
import java.util.Scanner;

import com.jlt.dao.EmployeeDao;
import com.jlt.pojo.Employee;
import java.util.List;

public class hgdrg 
{
private static EmployeeDao employeeDao;

public static void main(String[] args) {
	int employeeid;
	String name;
	double salary;
	
	Scanner scanner = new Scanner (System.in);
	System.out.println("Enter employee id");
	employeeid=scanner.nextInt();
	System.out.println("Enter name");
	name=scanner.next();
	System.out.println("Enter salary");
	salary=scanner.nextDouble();
	
	Employee employee = new Employee(employeeid,name,salary);
	//System.out.println(employee);
	if(employeeDao.addEmployee(employee)); 
	{
	
		
	}
}
}
