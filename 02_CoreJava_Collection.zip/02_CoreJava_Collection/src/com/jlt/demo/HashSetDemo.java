package com.jlt.demo;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class HashSetDemo
{
private Set<String> nameSet=new HashSet<String>();
public void printSet()
{
	nameSet.add("kjdf");
	nameSet.add("uktd");
	nameSet.add("tdt");
	nameSet.add("uktd");
	nameSet.add("udt");
	nameSet.add("ydft");
	nameSet.add("sutd");
	nameSet.add("dtftd");
	
	System.out.println(nameSet);
	for(String string : nameSet) {
		System.out.println("value::"+string+"HashCode::"+string.hashCode());
	}
	
}

}
