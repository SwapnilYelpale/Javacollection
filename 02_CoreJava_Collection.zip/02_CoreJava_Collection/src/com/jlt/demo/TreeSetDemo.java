package com.jlt.demo;

import java.util.Set;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.TreeSet;

public class TreeSetDemo
{
	private Set<String> nameSet=new TreeSet<String>();
	public void display()
	{
		nameSet.add("2");
		nameSet.add("1");
		nameSet.add("4");
		nameSet.add("0");
		nameSet.add("6");
		nameSet.add("3");
		System.out.println(nameSet);
	}
	

}
