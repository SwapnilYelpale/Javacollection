package com.jlt.demo;
import java.util.ArrayList;
import java.util.List;
public class ArrayListDemo 
{
private List<String> nameList=new ArrayList<String>();

public void print()
{
	System.out.println("size::"+nameList.size());
	nameList.add("Neel");
	nameList.add("Swap");
	nameList.add("praful");
	nameList.add("sameeksha");
	
	System.out.println("size ::"+nameList.size());
	System.out.println(nameList);
	nameList.remove("Neel");
	System.out.println(nameList);
}

}
