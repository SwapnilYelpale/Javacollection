package com.jlt.demo;
import java.util.Map;
import java.util.TreeMap;
public class TreeMapDemo 
{
private TreeMap<Integer,String> userMap=new TreeMap<Integer,String>();
public void print()
{
	

userMap.put(102,"Neel");
userMap.put(105,"swap");
userMap.put(103,"praful");
userMap.put(109,"rahul");
userMap.put(108,"sameeksha");

System.out.println(userMap);
}
}